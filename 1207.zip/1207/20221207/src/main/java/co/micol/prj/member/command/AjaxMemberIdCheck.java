package co.micol.prj.member.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.micol.prj.common.Command;
import co.micol.prj.member.service.MemberService;
import co.micol.prj.member.serviceImpl.MemberServiceImpl;

public class AjaxMemberIdCheck implements Command {

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		MemberService dao = new MemberServiceImpl();
		String id = request.getParameter("id");
		String result ="1"; //기본값으로 사용할수있도록 하기 위해. 존재하지않으면 1
		boolean b = dao.isIdCheck(id);
		if(!b) {
			result = "0";	//존재하면 0
		}
		
		return "Ajax:"+result;//ajax처리하는 것을 view resolve에 알림 
	}

}
